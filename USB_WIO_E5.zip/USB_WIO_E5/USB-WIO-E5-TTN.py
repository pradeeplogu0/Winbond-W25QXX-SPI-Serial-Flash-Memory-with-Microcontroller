# Import necessary libraries
import serial
import time
import random

# Initialize flags
is_join = False  # Flag to check if the device has joined the network
is_exist = False  # Flag to check if the device exists

# Set read timeout in seconds
read_timeout = 0.2

# Configure the LoRa serial connection
lora = serial.Serial(
    port='COM3',  # Serial port
    baudrate=9600,  # Baudrate
    bytesize=8,  # Bytesize
    parity='N',  # Parity
    timeout=1,  # Timeout
    stopbits=1,  # Stopbits
    xonxoff=False,  # XON/XOFF
    rtscts=False,  # RTS/CTS
    dsrdtr=False  # DSR/DTR
)


# Function to send a command and check the response
def envoi_test_reponse(chaine_verif, timeout_ms, commande):
    """
    Send a command to the LoRa device and check the response.

    Args:
        chaine_verif (str): The expected response string.
        timeout_ms (int): The timeout in milliseconds.
        commande (str): The command to send.

    Returns:
        int: 1 if the response matches the expected string, 0 otherwise.
    """
    if chaine_verif == "":
        return 0
    
    # Append newline characters to the command
    fin_ligne = "\r\n"
    cmd = "%s%s" % (commande, fin_ligne)
    print("Command = ", cmd)
    
    # Send the command to the LoRa device
    lora.write(cmd.encode())
    
    # Initialize the response string
    reponse = ""
    quantity = lora.in_waiting

    # Start the timer
    startMillis = int(round(time.time() * 1000))
    
    # Wait for the response or timeout
    while int(round(time.time() * 1000)) - startMillis < timeout_ms:
        if quantity > 0:
            # Read the response from the LoRa device
            reponse += lora.read(quantity).decode('utf-8')
            print("Reponse : ", reponse)
        else:
            # Sleep for a short period if no response is available
            time.sleep(read_timeout)
        quantity = lora.in_waiting

    print("Reponse : ", reponse)
    
    # Check if the response matches the expected string
    if chaine_verif in reponse:
        print("The response chain exists", reponse)
        return 1
    else:
        return 0


# Check if the LoRa device exists and configure it
if envoi_test_reponse("+AT: OK", 1000, "AT"):
    is_exist = True
    # Send configuration commands to the LoRa device
    envoi_test_reponse("+ID: AppEui", 1000, "AT+ID")
    envoi_test_reponse("+MODE: LWOTAA", 1000, "AT+MODE=LWOTAA")
    envoi_test_reponse("+DR: EU868", 1000, "AT+DR=EU868")
    envoi_test_reponse("+CH: NUM", 1000, "AT+CH=NUM,0-2")
    envoi_test_reponse("+KEY: APPKEY", 1000, "AT+KEY=APPKEY,\"2B7E151628AED2A6ABF7158809CF4F3C\"")
    envoi_test_reponse("+CLASS: C", 1000, "AT+CLASS=A")
    envoi_test_reponse("+PORT: 8", 1000, "AT+PORT=8")

    is_join = True
else:
    is_exist = False
    print("The LoRa E5 card was not found...")


# Main loop
while True:
    # Check if the LoRa device exists
    if is_exist:
        rep = 0
        
        # Check if the device needs to join the network
        if is_join:
            # Try to join the network
            rep = envoi_test_reponse("+JOIN: Network joined", 12000, "AT+JOIN")
            
            # If the join is successful, set the join flag to False
            if rep:
                is_join = False
            else:
                # If the join fails, send the ID command and wait
                envoi_test_reponse("+ID: AppEui", 1000, "AT+ID")
                print("Impossible to join the LoRa E5 to the network!!\r\n")
                time.sleep(5)

        else:
            # Generate a random number to send as a payload
            random_number = random.randint(10, 100)
            print("payload : ", random_number)
            temp = random_number

            # Convert the random number to a hexadecimal string
            payload = '{:04x}'.format(temp)
            payload1 = '{:04x}'.format(temp)
            CP = payload + payload1

            print("payload : ", CP)
            
            # Create the command to send the payload
            commande = "AT+CMSGHEX=" + CP + ""
            print("Commande : ", commande)

            # Send the payload and check the response
            rep = envoi_test_reponse("Done", 5000, commande)

            # Check if the payload was sent successfully
            if rep:
                print("L\'Data Sent Successfully\r\n")
            else:
                print("L\'Problem with Data Sent\r\n")
            
            # Wait for 5 seconds before sending the next payload
            time.sleep(5)
    else:
        # If the LoRa device does not exist, wait for 5 seconds
        time.sleep(5)
           