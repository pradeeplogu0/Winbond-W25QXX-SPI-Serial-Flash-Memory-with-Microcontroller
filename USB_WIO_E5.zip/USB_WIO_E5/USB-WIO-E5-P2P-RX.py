# Import the libraries
import serial
import time

# Definition of flags
is_join = False           # Can join the board
is_exist = False          # The Wio E5 board has been detected

# Definition of the timeout
read_timeout = 0.2

# Create the instance to manage the board via the serial port
lora = serial.Serial(
    port='COM3',
    baudrate=9600,
    bytesize=8,
    parity='N',
    timeout=1,
    stopbits=1,
    xonxoff=False,
    rtscts=False,
    dsrdtr=False
)

def envoi_test_reponse(chaine_verif, timeout_ms, commande):
    startMillis = int(round(time.time() * 1000))
    
    # Check if the verification string exists
    if chaine_verif == "":
        return 0
    
    # Send the command
    fin_ligne = "\r\n"
    cmd = "%s%s" % (commande, fin_ligne)
    print("Command sent = ", cmd)
    lora.write(cmd.encode())
    
    # Wait for the response
    reponse = ""
    quantity = lora.in_waiting
    # Read the response from the board until timeout
    while int(round(time.time() * 1000)) - startMillis < timeout_ms:
        # If we have data
        if quantity > 0:
            # Add them to the response string
            reponse += lora.read(quantity).decode('utf-8')
            print("Response from the board: ", reponse)

        else:
            # Otherwise wait a moment
            time.sleep(read_timeout) 
        # Check if we have received data
        quantity = lora.in_waiting

    print("Response from the board: ", reponse)
    
    # Check if the expected string exists
    if chaine_verif in reponse:
        print("The response string exists", reponse)
        return 1    
    else:
        return 0

    
# Board configuration

if envoi_test_reponse("+AT: OK", 1000, "AT"):
    # The board has been detected = set to True
    envoi_test_reponse("+MODE: TEST", 1000, "AT+MODE=TEST")

while True:
    envoi_test_reponse("+TEST: RX '0019001E'", 1000, "AT+TEST=RXLRPKT")
    time.sleep(1)
