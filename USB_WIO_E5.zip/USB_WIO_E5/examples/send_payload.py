
import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from loracap.LoRaMode import *

data_to_send = {
    "temperature": 22.5,
    "humidity": 48, 
}

class uploader(LoRaMode):
    def __init__(self):
        super(LoRaMode, self).__init__()
    
    def handle_line(self, line):
        self.responses.put(line)

while True:
    


    ser = serial.serial_for_url('COM3', baudrate=9600, timeout=1)
    with serial.threaded.ReaderThread(ser, uploader) as lorae5:
        lorae5.mode = 'TEST'
        encoded_data = json.dumps(data_to_send)
        
        print(f"Encoded data: {encoded_data}")
        
        status = lorae5.send_str(encoded_data)
        ret = "Success" if status else "Fail"
        
        status = lorae5.send_hex(encoded_data)
        ret = "Success" if status else "Fail"
        
        status = lorae5.send_hex(encoded_data.encode().hex())
        ret = "Success" if status else "Fail"
