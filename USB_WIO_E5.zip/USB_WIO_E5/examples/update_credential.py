import serial
import time

# Configure the serial port
lora = serial.Serial(
    port='COM3',  # Replace with your COM port
    baudrate=9600,
    bytesize=8,
    parity='N',
    stopbits=1,
    timeout=1
)

def send_command(command, timeout=1):
    lora.write((command + '\r\n').encode())
    time.sleep(timeout)
    response = lora.read_all().decode()
    return response

# Example: Send AT command and print the response
response = send_command('AT')
print('Response:', response)

# Example: Set the Wio E5 to test mode
response = send_command('AT+MODE=TEST')
print('Response:', response)

# Example: Send a test packet
response = send_command('AT+TEST=TXLRPKT,"Hello, LoRa!"')
print('Response:', response)
