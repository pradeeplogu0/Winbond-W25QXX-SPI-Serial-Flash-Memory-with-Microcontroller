import serial

# Open the serial port
ser = serial.Serial('COM23', 9600, timeout=1)  # Replace COMX with the actual COM port number

# Set the WIO E5 module to LoRaWAN mode
ser.write(b'AT+MODE=LW\r\n')
ser.readline()

# Set the frequency band (e.g., EU868)
ser.write(b'AT+BAND=EU868\r\n')
ser.readline()

# Set the device address (e.g., 0x12345678)
ser.write(b'AT+ADDR=0x12345678\r\n')
ser.readline()

# Save the changes
ser.write(b'AT+SAVE\r\n')
ser.readline()

# Close the serial port
ser.close()